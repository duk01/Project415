University Library Management System

Database is included -- connect to Docker & fill in your username and password.

Website published with a book catalog, homepage, and user authentication.

Additional features pending.
